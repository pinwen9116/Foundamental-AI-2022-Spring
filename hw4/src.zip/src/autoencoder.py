from data_transformer import DataTransformer
import torch
import torch.nn as nn
from torch.optim import Adam
from torch.utils.data import DataLoader
from tqdm import trange

class AutoencoderModel(nn.Module):
    """Add more of your code here if you want to"""
    def __init__(self, latent_space_dim, architecture_callback):
        super().__init__()
        architecture_callback(self, latent_space_dim)

class Autoencoder(DataTransformer):
    """Add more of your code here if you want to"""
    def __init__(self, args, architecture_callback):
        self.args = args
        self.model = AutoencoderModel(args.latent_space_dim, architecture_callback).to(args.device)

    def fit(self, X):
        raise NotImplementedError
    
    def transform(self, X):
        raise NotImplementedError
    
    def reconstruct(self, X_transformed):
        raise NotImplementedError

class DenoisingAutoencoder(Autoencoder):
    """Add more of your code here if you want to"""
    def __init__(self, args, architecture_callback):
        super().__init__(args, architecture_callback)