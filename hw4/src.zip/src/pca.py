from data_transformer import DataTransformer
import numpy as np

class PCA(DataTransformer):
    """
    Add more of your code here if you want to
    Parameters
    ----------
    n_components : int
        Number of components to keep.
    """
    def __init__(self, args):
        self.n_components = args.latent_space_dim

    def fit(self, X):
        raise NotImplementedError
    
    def transform(self, X):
        raise NotImplementedError

    
    def reconstruct(self, X_transformed):
        """
        Reconstruct the transformed X
        Parameters
        ----------
        X_transformed : array-like of shape (n_samples, n_features)
            Training data, where `n_samples` is the number of samples
            and `n_features` is the number of features.

        Returns
        -------
        X_reconstructed : ndarray of shape (n_samples, n_components)
            of reconstructed values.
        """
        raise NotImplementedError
